# Near-APP

> Repository for **neara** — a privacy-first dating app concept. Discovery happens on a
map, but never with exact pins. People show up as **approximate privacy circles**, your
own location is a soft area, and zoom is capped so no one can drill down to a doorstep.

> Demo app: profiles and locations are synthetic. No real users, no real coordinates.

## Stack

- **Vite** + **React 18** + **TypeScript**
- **Tailwind CSS** + **shadcn/ui** (Radix primitives)
- **MapLibre GL** for the interactive map (free, no API key required)
- **React Router**, **TanStack Query**, **framer-motion**, **Rive**
- **Vitest** + Testing Library

## Getting started

```bash
npm install
npm run dev
```

Open the local URL Vite prints. No `.env` is needed to run.

### Scripts

| Command | What it does |
| --- | --- |
| `npm run dev` | Start the dev server |
| `npm run build` | Production build |
| `npm run preview` | Preview the production build |
| `npm run lint` | Lint |
| `npm test` | Run the test suite |

## The map

The map (`src/components/neara/NearaMapGL.tsx`) is a real MapLibre GL map wearing
neara's skin: a free CARTO dark basemap under a plum tint, drifting fog, vignette,
breathing "social-energy" zones, and glowing approximate privacy circles. It follows
the user's chosen accent theme automatically, and is lazy-loaded so MapLibre stays out
of the initial bundle.

Placement math and config live in `src/lib/geo.ts`.

### Optional configuration

Everything works with zero config. To customize, copy `.env.example` to `.env`:

```bash
VITE_MAP_CENTER=-80.1918,25.7617   # "lng,lat" — approximate center (default: Miami)
VITE_MAP_STYLE=<style url>         # swap the basemap for any MapLibre style
VITE_MAPBOX_TOKEN=<token>          # use Mapbox dark-v11 instead of CARTO
```

## Project structure

```
src/
  components/
    neara/        # app-specific components (map, brand, profile UI, etc.)
    ui/           # shadcn/ui primitives
  pages/
    app/          # authenticated app screens (map, matches, chat, safety, ...)
  lib/            # types, demo data, geo helpers, sounds, safety
  store/          # app-wide state (AppStore)
  test/           # vitest specs
```
